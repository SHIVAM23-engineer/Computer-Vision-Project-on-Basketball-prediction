# basketball_prediction
mini project to determine whether a basketball shot will make it inside the hoop or not using AI/ ML.
